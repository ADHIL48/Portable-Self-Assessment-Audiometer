# Hearing Test

A simple tone generator using pyaudio wrapped in a tkinter gui. It can be used as the basis for hearing test experiments.

Click "Increase" to cause the pitch to rize 50Hz every 0.1 seconds to a maximum frequency of 25KHz. Have participants click "Freeze" when they can no longer hear the sound, to find the maximum frequency they are able to hear. Children can probably hear much higher frequency sounds than adults!
