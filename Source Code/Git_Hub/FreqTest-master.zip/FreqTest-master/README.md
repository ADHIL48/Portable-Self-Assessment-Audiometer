# FreqTest
Quick and simple frequency hearing test.

My score is around 19500Hz as of December 2019.
